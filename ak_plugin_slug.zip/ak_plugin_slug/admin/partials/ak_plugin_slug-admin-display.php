<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       ak_plugin_auther_uri
 * @since      1.0.0
 *
 * @package    Ak_plugin_slug
 * @subpackage Ak_plugin_slug/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
